# ============================================================
# 01_importar_datos.R
# Importacion y diagnostico inicial
# ============================================================

source(here::here("R", "00_setup.R"))

personas_raw <- readr::read_csv(
  here::here("data", "raw", "personas_pensiones_sintetica.csv"),
  show_col_types = FALSE
)

personas <- personas_raw |>
  janitor::clean_names()

print(glimpse(personas))
print(skimr::skim(personas))
