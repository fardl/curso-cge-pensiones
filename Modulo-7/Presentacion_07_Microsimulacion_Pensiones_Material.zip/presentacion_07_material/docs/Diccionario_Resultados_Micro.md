# Diccionario de resultados de la microsimulacion

## resultados_individuales_base.csv

- `saldo_retiro`: saldo proyectado al momento de retiro.
- `salario_final_anual`: salario anual proyectado antes de retiro.
- `pension_autofinanciada_anual`: pension anual financiada solo con el saldo individual.
- `pension_final_anual`: pension despues de aplicar pension minima o pilar solidario.
- `costo_fiscal_anual`: diferencia entre pension minima y pension autofinanciada, cuando aplica.
- `tasa_reemplazo`: pension final anual dividida por salario final anual.
- `densidad_simulada`: densidad usada en el escenario.

## resumen_escenarios_micro.csv

- `pension_promedio_ponderada`: pension promedio usando factores de expansion.
- `pension_mediana`: mediana simple de la pension final anual.
- `tr_promedio_ponderada`: tasa de reemplazo promedio ponderada.
- `tr_mediana`: mediana simple de la tasa de reemplazo.
- `porc_bajo_minimo_autofinanciado`: proporcion ponderada cuya pension autofinanciada queda bajo el umbral ilustrativo.
- `costo_fiscal_total_anual`: costo fiscal anual agregado del pilar solidario.
- `saldo_retiro_promedio`: saldo promedio ponderado al retiro.

## resumen_topdown_cge_micro.csv

- `escenario_cge`: escenario macro proveniente del CGE.
- `pension_promedio`: pension promedio despues del choque macro.
- `tr_promedio`: tasa de reemplazo promedio despues del choque macro.
- `fondo_promedio_retiro`: saldo promedio al retiro despues del choque macro.
- `contribuciones_agregadas_aprox`: masa de contribuciones aproximada agregada desde microdatos.
