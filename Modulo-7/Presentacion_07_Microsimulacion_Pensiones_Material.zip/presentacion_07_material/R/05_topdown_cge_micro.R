# ==========================================================
# Integracion top-down CGE -> Microsimulacion
# ==========================================================

source("R/02_simular_cuentas_individuales.R")

choques_cge <- read_csv(file.path(paths$data, "choques_cge_ejemplo.csv"), show_col_types = FALSE)

aplicar_choque_cge <- function(base_micro, delta_salario_real, delta_empleo_formal,
                               delta_retorno_real) {
  # Esta funcion muestra la idea top-down de forma pedagogica.
  # En una aplicacion real, el choque podria diferenciar por sector,
  # skill, sexo, edad o condicion de formalidad.
  base_micro %>%
    mutate(
      salario_mensual = salario_mensual * (1 + delta_salario_real),
      densidad_historica = pmin(pmax(densidad_historica + delta_empleo_formal, 0), 1),
      retorno_micro = get_param("retorno_real_anual") + delta_retorno_real
    )
}

resumen_topdown <- purrr::map_dfr(seq_len(nrow(choques_cge)), function(k) {
  ch <- choques_cge[k, ]
  micro_chocado <- aplicar_choque_cge(
    micro,
    delta_salario_real = ch$delta_salario_real,
    delta_empleo_formal = ch$delta_empleo_formal,
    delta_retorno_real = ch$delta_retorno_real
  )

  res <- simular_micro(
    micro_chocado,
    tasa_aporte = get_param("tasa_aporte_capitalizable"),
    edad_retiro = get_param("edad_retiro_base"),
    retorno_real = get_param("retorno_real_anual") + ch$delta_retorno_real,
    crecimiento_salario = get_param("crecimiento_salario_real") + ch$delta_salario_real,
    shock_densidad = 0,
    pension_minima = 0,
    tasa_tecnica = get_param("tasa_tecnica_anual")
  )

  tibble(
    escenario_cge = ch$escenario_cge,
    pension_promedio = weighted_mean(res$pension_final_anual, res$peso),
    tr_promedio = weighted_mean(res$tasa_reemplazo, res$peso),
    fondo_promedio_retiro = weighted_mean(res$saldo_retiro, res$peso),
    contribuciones_agregadas_aprox = sum(res$salario_mensual * 12 * res$densidad_simulada * get_param("tasa_aporte_capitalizable") * res$peso, na.rm = TRUE)
  )
})

write_csv(resumen_topdown, file.path(paths$outputs, "resumen_topdown_cge_micro.csv"))
message("Resultados top-down guardados en outputs/resumen_topdown_cge_micro.csv")
