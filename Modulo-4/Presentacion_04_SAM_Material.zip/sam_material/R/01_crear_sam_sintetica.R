# 01_crear_sam_sintetica.R
# Crea una SAM sintetica balanceada desde un archivo de flujos en formato largo.
# Ejecutar desde la carpeta sam_material/

source("R/00_setup.R")

flows_path <- "data/flujos_sam_sintetica_rd.csv"
if (!file.exists(flows_path)) stop("No existe el archivo: ", flows_path)

flows <- read.csv(flows_path, stringsAsFactors = FALSE)
accounts <- unique(c(flows$recibe, flows$paga))

sam <- matrix(0, nrow = length(accounts), ncol = length(accounts),
              dimnames = list(accounts, accounts))

for (i in seq_len(nrow(flows))) {
  sam[flows$recibe[i], flows$paga[i]] <- sam[flows$recibe[i], flows$paga[i]] + flows$valor[i]
}

write.csv(sam, "data/sam_sintetica_rd_generada.csv")
message("SAM sintetica generada en data/sam_sintetica_rd_generada.csv")
