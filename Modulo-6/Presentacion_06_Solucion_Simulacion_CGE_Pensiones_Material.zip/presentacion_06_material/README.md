# Presentacion 6 - Solucion y Simulacion del Modelo CGE con Pensiones

Este paquete contiene la presentacion Beamer y material R para una sesion aplicada sobre solucion y simulacion de reformas previsionales en un modelo CGE.

## Contenido

- `latex/Presentacion_06_Solucion_Simulacion_CGE_Pensiones.tex`: fuente Beamer.
- `latex/Presentacion_06_Solucion_Simulacion_CGE_Pensiones.pdf`: PDF compilado.
- `R/00_setup.R`: rutas y lectura de parametros.
- `R/01_modelo_cge_pensiones.R`: funciones del modelo didactico.
- `R/02_simular_reformas.R`: corrida de escenarios.
- `R/03_visualizar_resultados.R`: graficos de resultados.
- `data/parametros_base.csv`: parametros pedagogicos.
- `data/escenarios_reforma.csv`: escenarios de politica.
- `outputs/*_ejemplo.csv`: resultados generados como referencia.
- `docs/Guia_Modulo_06_Solucion_Simulacion.md`: guia de uso.
- `docs/Diccionario_Variables.md`: variables del modelo.

## Como ejecutar en RStudio

1. Abrir RStudio en esta carpeta.
2. Ejecutar `source("R/02_simular_reformas.R")`.
3. Ejecutar `source("R/03_visualizar_resultados.R")` para graficos.

Los resultados se guardan en `outputs/`.

## Nota

Los numeros son pedagogicos. Sirven para explicar mecanismos de equilibrio general y no deben interpretarse como resultados oficiales para Republica Dominicana.
