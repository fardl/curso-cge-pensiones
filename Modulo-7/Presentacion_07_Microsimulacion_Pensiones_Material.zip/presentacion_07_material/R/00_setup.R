# ==========================================================
# Curso CGE y Microsimulacion de Pensiones - Sesion 7
# Setup del proyecto
# ==========================================================

# Este script define rutas y carga paquetes. Para mantener el
# ejercicio reproducible, se asume que el directorio de trabajo
# es la raiz del material de la sesion.

required_packages <- c("dplyr", "readr", "tidyr", "ggplot2", "purrr", "scales")

load_or_stop <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop(sprintf("Falta el paquete '%s'. Instale con install.packages('%s').", pkg, pkg))
  }
  suppressPackageStartupMessages(library(pkg, character.only = TRUE))
}

invisible(lapply(required_packages, load_or_stop))

paths <- list(
  data = "data",
  outputs = "outputs",
  figures = "figures",
  docs = "docs"
)

invisible(lapply(paths, dir.create, recursive = TRUE, showWarnings = FALSE))

weighted_mean <- function(x, w) {
  ok <- !is.na(x) & !is.na(w)
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_share <- function(condition, w) {
  weighted_mean(as.numeric(condition), w)
}

# Cuantil ponderado sencillo para uso pedagogico.
weighted_quantile <- function(x, w, probs = c(0.5)) {
  ok <- !is.na(x) & !is.na(w)
  x <- x[ok]
  w <- w[ok]
  ord <- order(x)
  x <- x[ord]
  w <- w[ord]
  cw <- cumsum(w) / sum(w)
  sapply(probs, function(p) x[which(cw >= p)[1]])
}
