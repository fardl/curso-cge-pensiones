# ==========================================================
# Visualizacion de resultados de microsimulacion
# ==========================================================

source("R/00_setup.R")

resultados <- read_csv(file.path(paths$outputs, "resultados_individuales_escenarios.csv"), show_col_types = FALSE)
resumen_quintiles <- read_csv(file.path(paths$outputs, "resumen_quintiles_escenarios.csv"), show_col_types = FALSE)

escenarios_mostrar <- c("base", "aporte_mayor", "edad_retiro_mayor", "pilar_solidario", "paquete_integral")

p1 <- resultados %>%
  filter(escenario %in% escenarios_mostrar, tasa_reemplazo < 2) %>%
  ggplot(aes(x = tasa_reemplazo, weight = peso)) +
  geom_density() +
  facet_wrap(~ escenario, ncol = 2) +
  scale_x_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    title = "Distribucion ponderada de tasas de reemplazo",
    x = "Tasa de reemplazo",
    y = "Densidad"
  ) +
  theme_minimal()

ggsave(file.path(paths$figures, "densidad_tasas_reemplazo.png"), p1, width = 9, height = 6, dpi = 150)

p2 <- resumen_quintiles %>%
  filter(escenario %in% escenarios_mostrar) %>%
  ggplot(aes(x = factor(quintil), y = tr_promedio, group = escenario)) +
  geom_line() +
  geom_point() +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    title = "Tasa de reemplazo promedio por quintil",
    x = "Quintil",
    y = "Tasa de reemplazo promedio"
  ) +
  theme_minimal()

ggsave(file.path(paths$figures, "tasa_reemplazo_quintil.png"), p2, width = 9, height = 5.5, dpi = 150)

p3 <- resultados %>%
  filter(escenario %in% c("base", "paquete_integral")) %>%
  group_by(escenario, sexo) %>%
  summarise(
    pension_promedio = weighted_mean(pension_final_anual, peso),
    .groups = "drop"
  ) %>%
  ggplot(aes(x = sexo, y = pension_promedio)) +
  geom_col() +
  facet_wrap(~ escenario) +
  labs(
    title = "Pension promedio por sexo",
    x = NULL,
    y = "Pension anual promedio"
  ) +
  theme_minimal()

ggsave(file.path(paths$figures, "pension_promedio_sexo.png"), p3, width = 8, height = 5, dpi = 150)

message("Graficos guardados en figures/.")
