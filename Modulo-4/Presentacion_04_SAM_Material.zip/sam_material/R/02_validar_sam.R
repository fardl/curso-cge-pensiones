# 02_validar_sam.R
# Valida equilibrio contable de una SAM: filas = ingresos, columnas = gastos.
# Ejecutar desde la carpeta sam_material/

source("R/00_setup.R")

sam_path <- "data/sam_sintetica_rd.csv"
if (!file.exists(sam_path)) stop("No existe el archivo: ", sam_path)

sam <- as.matrix(read.csv(sam_path, row.names = 1, check.names = FALSE))
storage.mode(sam) <- "numeric"

ingresos <- rowSums(sam)
gastos <- colSums(sam)

diagnostico <- data.frame(
  cuenta = rownames(sam),
  ingresos = ingresos,
  gastos = gastos,
  diferencia = ingresos - gastos,
  diferencia_abs = abs(ingresos - gastos),
  row.names = NULL
)

write.csv(diagnostico, "outputs/tables/diagnostico_balance_sam.csv", row.names = FALSE)

print(diagnostico)

max_diff <- max(abs(diagnostico$diferencia))
message("Diferencia maxima absoluta: ", round(max_diff, 8))

if (max_diff < 1e-8) {
  message("SAM balanceada: ingresos y gastos coinciden por cuenta.")
} else {
  warning("SAM desbalanceada: revisar outputs/tables/diagnostico_balance_sam.csv")
}
