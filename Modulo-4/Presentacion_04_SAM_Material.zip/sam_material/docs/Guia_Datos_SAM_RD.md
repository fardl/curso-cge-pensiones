
# Guia de datos para construir una SAM de la economia dominicana con modulo previsional

## 1. Recomendacion de año base

Para una primera SAM estructural se recomienda iniciar con **2018/2019**, porque permite combinar la ENGIH 2018 con cuentas nacionales recientes y evita parte de la distorsion de la pandemia. Para una SAM de simulacion de politica actual, se puede actualizar a **2024/2025** usando cuentas nacionales, datos fiscales, TSS y SIPEN.

## 2. Bloque productivo

Conseguir:

- Cuadros Oferta y Utilizacion (COU) en valores corrientes.
- Matriz Insumo-Producto (MIP) disponible.
- PIB por actividad economica.
- Formacion bruta de capital fijo por sector y tipo de bien.
- Exportaciones e importaciones por producto.

Uso:

- Construir consumo intermedio.
- Calibrar produccion sectorial.
- Asignar demanda final: hogares, gobierno, inversion y resto del mundo.

## 3. Mercado laboral

Conseguir:

- Ocupados por actividad.
- Ingreso laboral por sector.
- Formalidad e informalidad.
- Masa salarial cotizable.
- Empleos cotizantes y empleadores cotizantes.

Uso:

- Separar trabajo formal e informal.
- Calibrar contribuciones previsionales.
- Identificar la base salarial sujeta a cotizacion.

## 4. Hogares

Conseguir:

- Ingreso por fuente: laboral, capital, transferencias, remesas, pensiones.
- Consumo por rubro.
- Pesos muestrales.
- Quintiles o deciles.
- Edad, sexo, formalidad y region.

Uso:

- Distribuir ingreso factorial.
- Distribuir consumo final.
- Estimar ahorro por grupo.
- Preparar la conexion con microsimulacion.

## 5. Pensiones y seguridad social

Conseguir:

- Afiliados.
- Cotizantes.
- Masa salarial cotizable.
- Contribuciones recaudadas.
- Fondos administrados.
- Rentabilidad.
- Pensiones pagadas.
- Comisiones.
- Portafolio de inversion de fondos.

Uso:

- Construir la cuenta AFP/fondos.
- Calibrar la tasa efectiva de contribucion.
- Relacionar ahorro previsional con inversion.
- Conectar beneficios con hogares retirados.

## 6. Gobierno y fisco

Conseguir:

- Recaudacion efectiva por impuesto.
- ITBIS/IVA.
- ISR salarios.
- ISR empresas.
- Aranceles.
- Gasto corriente.
- Transferencias sociales.
- Gasto de capital.
- Intereses de deuda.

Uso:

- Construir cuenta de gobierno.
- Calibrar tasas efectivas de impuestos.
- Medir costo fiscal de reformas previsionales.

## 7. Sector externo

Conseguir:

- Exportaciones.
- Importaciones.
- Remesas.
- Balanza de pagos.
- Renta factorial.
- Ahorro externo.

Uso:

- Construir cuenta resto del mundo.
- Definir cierre externo del modelo CGE.

## 8. Reglas de consistencia

- Trabajar en pesos corrientes del mismo año.
- Documentar si los datos estan en FOB, CIF, valor basico o precio comprador.
- No mezclar unidades mensuales, trimestrales y anuales sin anualizar.
- Conservar trazabilidad: fuente, tabla, año, unidad y transformacion.
- Separar dato observado, supuesto y valor balanceado.

## 9. Producto esperado

Una SAM dominicana inicial debe contener al menos:

- Produccion por 3 a 10 sectores.
- Trabajo formal e informal.
- Capital.
- Hogares por quintil.
- Gobierno.
- AFP/fondos de pensiones.
- Ahorro-inversion.
- Resto del mundo.

La version avanzada puede desagregar hogares por edad, sexo, formalidad y cohortes para conectarla con microsimulacion previsional.
