# ================================================================
# Sesion 6 - Solucion y simulacion del modelo CGE con pensiones
# 00_setup.R
# ================================================================
# Este script prepara rutas y lee insumos basicos. Esta pensado para
# ejecutarse desde la carpeta raiz del material de la sesion.

root <- getwd()
paths <- list(
  data = file.path(root, "data"),
  outputs = file.path(root, "outputs"),
  R = file.path(root, "R")
)

for (p in paths) {
  if (!dir.exists(p)) dir.create(p, recursive = TRUE)
}

leer_parametros <- function(path = file.path(paths$data, "parametros_base.csv")) {
  x <- read.csv(path, stringsAsFactors = FALSE)
  par <- as.list(setNames(x$valor, x$parametro))
  par <- lapply(par, as.numeric)
  par
}

leer_escenarios <- function(path = file.path(paths$data, "escenarios_reforma.csv")) {
  read.csv(path, stringsAsFactors = FALSE)
}
