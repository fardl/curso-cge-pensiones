# Guia de datos para microsimulacion previsional

Esta guia resume los datos que conviene conseguir para transformar el ejercicio sintetico de la Sesion 7 en una microsimulacion aplicada a la Republica Dominicana.

## 1. Microdatos laborales y de hogares

Variables minimas:

- identificador anonimo de persona y hogar;
- factor de expansion;
- edad, sexo, educacion y region;
- condicion laboral: formal, informal, desempleado, inactivo;
- salario laboral e ingreso total;
- sector de actividad y tipo de ocupacion;
- horas trabajadas;
- quintil o decil de ingreso;
- consumo del hogar y lineas de pobreza cuando esten disponibles.

Fuentes sugeridas:

- ENCFT para empleo, ingresos laborales y formalidad;
- ENGIH/ENIGH para ingresos, consumo, quintiles y estructura del hogar;
- ONE para demografia y estructura poblacional.

## 2. Datos administrativos previsionales

Variables de mayor valor para el modelo:

- afiliados por edad, sexo, AFP, region y fecha;
- cotizantes por edad, sexo, AFP, region y fecha;
- salario cotizable por individuo o grupo;
- meses cotizados por individuo o grupo;
- densidad de cotizacion mensual/anual;
- saldo acumulado en cuenta individual;
- aportes obligatorios y voluntarios;
- rentabilidad nominal y real de fondos;
- comisiones y seguros;
- beneficios otorgados por vejez, discapacidad y sobrevivencia.

Fuentes sugeridas:

- SIPEN: boletines, tablero interactivo y datos abiertos;
- TSS/SUIR: recaudacion, salarios cotizables y cotizaciones;
- CNSS y normativa complementaria para reglas vigentes.

## 3. Datos macro para integracion con CGE

Variables necesarias:

- crecimiento salarial real;
- inflacion;
- productividad;
- empleo formal e informal por sector;
- retorno real esperado del fondo;
- tasa de interes y retorno de instrumentos financieros;
- PIB, consumo, inversion y ahorro;
- recaudacion y gasto fiscal asociado a pensiones.

Fuentes sugeridas:

- BCRD para macro, precios, producto, tasas y cuentas nacionales;
- Ministerio de Hacienda/DIGEPRES para gasto fiscal;
- DGII/TSS para impuestos y contribuciones.

## 4. Reglas del sistema previsional

Se debe documentar:

- edad de retiro;
- tasa de aporte total y aporte capitalizable;
- comisiones y seguros;
- reglas de pension minima o pilar solidario si aplica;
- condiciones de acceso a beneficios;
- metodo de conversion de saldo en pension;
- tablas de mortalidad o expectativa de vida.

## 5. Recomendaciones de validacion

Antes de simular reformas:

1. Validar que la poblacion expandida coincida con agregados oficiales.
2. Validar salarios por percentil contra encuestas y datos administrativos.
3. Validar cotizantes y afiliados contra SIPEN/TSS.
4. Validar densidad promedio y por grupo.
5. Validar saldos acumulados agregados.
6. Validar que el costo fiscal de beneficios no contributivos tenga magnitud plausible.
7. Documentar todo supuesto que no provenga directamente de datos.

## 6. Confidencialidad

Para datos administrativos individuales, trabajar siempre con bases anonimizadas y aplicar protocolos de seguridad: separacion de identificadores, acceso restringido, revision de salidas, agregacion minima y proteccion de datos personales.
