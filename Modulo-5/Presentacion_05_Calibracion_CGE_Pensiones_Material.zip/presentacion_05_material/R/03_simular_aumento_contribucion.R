# Simulacion contable preliminar: aumento de contribucion previsional
# Nota: esto NO reemplaza al CGE completo; sirve para ver el canal de calibracion.
source("R/00_setup.R")

params <- readRDS(file.path(paths$outputs, "parametros_calibrados.rds"))

simulate_contribution <- function(params, new_contr_wage_rate, mpc = NULL) {
  L0 <- params$base$L0
  YH0 <- params$household$YH0
  C0 <- params$household$C0
  Contr0 <- params$household$contr_wage_rate * L0
  if (is.null(mpc)) {
    mpc <- params$household$c_share
  }
  Contr1 <- new_contr_wage_rate * L0
  dContr <- Contr1 - Contr0
  C1 <- C0 - mpc * dContr
  AFP_saving1 <- params$pension$s_afp * (params$pension$YAFP0 + dContr)
  data.frame(
    indicador = c("Contribucion AFP", "Consumo hogares", "Ahorro AFP"),
    base = c(Contr0, C0, params$pension$s_afp * params$pension$YAFP0),
    reforma = c(Contr1, C1, AFP_saving1),
    cambio = c(Contr1 - Contr0, C1 - C0, AFP_saving1 - params$pension$s_afp * params$pension$YAFP0)
  )
}

resultado <- simulate_contribution(params, new_contr_wage_rate = 0.18)
print(resultado)
write.csv(resultado, file.path(paths$outputs, "simulacion_aumento_contribucion.csv"), row.names = FALSE)
