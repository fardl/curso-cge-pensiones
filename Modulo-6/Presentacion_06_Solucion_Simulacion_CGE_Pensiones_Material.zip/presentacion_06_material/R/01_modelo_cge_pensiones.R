# ================================================================
# Sesion 6 - Solucion y simulacion del modelo CGE con pensiones
# 01_modelo_cge_pensiones.R
# ================================================================
# Modelo didactico agregado. No sustituye un CGE multisectorial, pero
# reproduce la logica de equilibrio, cierre laboral, ahorro-inversion y
# cuenta previsional de capitalizacion individual.

modificar_parametros <- function(par, shock = list()) {
  p <- par
  for (nm in names(shock)) p[[nm]] <- shock[[nm]]

  if (is.null(p$formal_share)) p$formal_share <- p$formal0
  if (is.null(p$pilar)) p$pilar <- 0
  if (is.null(p$oferta_laboral_extra)) p$oferta_laboral_extra <- 0
  if (is.null(p$beneficios_factor)) p$beneficios_factor <- 1

  # Formalidad cae cuando la contribucion supera la tasa base.
  p$formal_share <- max(
    0.20,
    min(0.90, p$formal0 - p$eta_formal * (p$tau_p - p$tau_p_base))
  )

  # Variables base para calibrar oferta laboral.
  A0 <- p$Y0 / (p$K0^p$alpha * p$L0^(1 - p$alpha))
  w0 <- (1 - p$alpha) * p$Y0 / p$L0
  p$A0 <- A0
  p$w0 <- w0
  p$wnet0 <- w0 * (1 - p$tau_l - p$tau_p_base * p$formal0)
  p
}

calcular_cuentas <- function(p, L_star, A) {
  K <- p$K0
  Y <- A * K^p$alpha * L_star^(1 - p$alpha)
  w <- (1 - p$alpha) * Y / L_star
  r <- p$alpha * Y / K
  wage_bill <- w * L_star
  capital_income <- r * K

  L_formal <- p$formal_share * L_star
  wage_bill_formal <- p$formal_share * wage_bill

  contribuciones_afp <- p$tau_p * wage_bill_formal
  beneficios <- p$beneficios_base * p$beneficios_factor
  comisiones <- p$comision_afp * contribuciones_afp

  impuestos_laborales <- p$tau_l * wage_bill

  ingreso_disponible <- wage_bill - impuestos_laborales - contribuciones_afp +
    capital_income + p$transferencias + beneficios + p$pilar

  consumo <- p$propension_consumo * ingreso_disponible
  impuestos_consumo <- p$tau_c * consumo
  impuestos_capital <- p$tau_k * capital_income

  ingreso_gobierno <- impuestos_laborales + impuestos_consumo + impuestos_capital
  gasto_gobierno_total <- p$gasto_gobierno + p$transferencias + p$pilar
  balance_fiscal <- ingreso_gobierno - gasto_gobierno_total

  ahorro_voluntario <- max(ingreso_disponible - consumo, 0)
  ahorro_afp <- contribuciones_afp - beneficios - comisiones
  ahorro_total <- ahorro_voluntario + balance_fiscal + ahorro_afp + p$ahorro_externo
  inversion <- max(ahorro_total, 0)

  K_siguiente <- (1 - p$delta) * K + inversion
  activos_afp_siguiente <- (1 + p$r_f) * p$afp_assets0 + contribuciones_afp - beneficios - comisiones

  salario_neto_promedio <- w * (1 - p$tau_l - p$tau_p * p$formal_share)
  bienestar_proxy <- log(max(consumo, 1e-6)) - p$phi_trabajo * (L_star / p$L0)^(1 + 1 / max(p$eps_l, 0.01))

  list(
    PIB = Y,
    empleo = L_star,
    empleo_formal = L_formal,
    salario_bruto = w,
    salario_neto = salario_neto_promedio,
    consumo = consumo,
    inversion = inversion,
    ahorro_total = ahorro_total,
    ahorro_voluntario = ahorro_voluntario,
    contribuciones_afp = contribuciones_afp,
    ahorro_afp = ahorro_afp,
    activos_afp_siguiente = activos_afp_siguiente,
    beneficios = beneficios,
    balance_fiscal = balance_fiscal,
    ingreso_gobierno = ingreso_gobierno,
    gasto_gobierno = gasto_gobierno_total,
    formalidad = p$formal_share,
    capital_siguiente = K_siguiente,
    bienestar_proxy = bienestar_proxy
  )
}

resolver_cge <- function(par, shock = list()) {
  p <- modificar_parametros(par, shock)
  A <- p$A0

  objetivo_laboral <- function(L) {
    if (L <= 0) return(1e20)
    Y <- A * p$K0^p$alpha * L^(1 - p$alpha)
    w <- (1 - p$alpha) * Y / L
    wnet <- w * (1 - p$tau_l - p$tau_p * p$formal_share)
    Ls <- p$L0 * (wnet / p$wnet0)^p$eps_l * (1 + p$oferta_laboral_extra)
    (L - Ls)^2
  }

  intervalo <- c(0.50 * p$L0, 1.60 * p$L0)
  L_star <- optimize(objetivo_laboral, intervalo)$minimum
  calcular_cuentas(p, L_star, A)
}

comparar_con_base <- function(resultados) {
  base <- resultados[["base"]]
  out <- list()
  for (esc in names(resultados)) {
    x <- resultados[[esc]]
    comunes <- intersect(names(base), names(x))
    out[[esc]] <- data.frame(
      escenario = esc,
      variable = comunes,
      valor = as.numeric(unlist(x[comunes])),
      base = as.numeric(unlist(base[comunes])),
      cambio_pct = 100 * (as.numeric(unlist(x[comunes])) / as.numeric(unlist(base[comunes])) - 1),
      row.names = NULL
    )
  }
  do.call(rbind, out)
}
