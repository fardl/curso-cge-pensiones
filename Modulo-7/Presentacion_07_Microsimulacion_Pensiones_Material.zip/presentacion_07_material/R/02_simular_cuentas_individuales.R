# ==========================================================
# Simulacion de cuentas individuales y tasas de reemplazo
# ==========================================================

source("R/00_setup.R")

micro <- read_csv(file.path(paths$data, "microdatos_sinteticos.csv"), show_col_types = FALSE)
parametros <- read_csv(file.path(paths$data, "parametros_previsionales.csv"), show_col_types = FALSE)

get_param <- function(nombre) {
  parametros$valor[parametros$parametro == nombre][1]
}

simular_cuenta_individual <- function(edad, salario_mensual, saldo_inicial,
                                      densidad, edad_retiro = 65,
                                      tasa_aporte = 0.10,
                                      retorno_real = 0.045,
                                      crecimiento_salario = 0.018) {
  retiro <- max(edad_retiro, edad + 1)
  anios <- retiro - edad
  saldo <- saldo_inicial
  salario_anual <- salario_mensual * 12

  for (t in seq_len(anios)) {
    aporte <- tasa_aporte * salario_anual * densidad
    saldo <- saldo * (1 + retorno_real) + aporte
    salario_anual <- salario_anual * (1 + crecimiento_salario)
  }

  list(
    saldo_retiro = saldo,
    salario_final_anual = salario_anual,
    anios_proyectados = anios
  )
}

factor_actuarial <- function(edad_retiro = 65, esperanza_vida = 83, tasa_tecnica = 0.03) {
  n <- max(round(esperanza_vida - edad_retiro), 1)
  sum(1 / (1 + tasa_tecnica)^(0:n))
}

calcular_pension_anual <- function(saldo_retiro, edad_retiro = 65,
                                   esperanza_vida = 83, tasa_tecnica = 0.03) {
  saldo_retiro / factor_actuarial(edad_retiro, esperanza_vida, tasa_tecnica)
}

simular_micro <- function(base_micro,
                          tasa_aporte = 0.10,
                          edad_retiro = 65,
                          retorno_real = 0.045,
                          crecimiento_salario = 0.018,
                          shock_densidad = 0,
                          pension_minima = 0,
                          tasa_tecnica = 0.03) {
  base_micro %>%
    mutate(
      densidad_simulada = pmin(pmax(densidad_historica + shock_densidad, 0), 1)
    ) %>%
    rowwise() %>%
    mutate(
      sim = list(simular_cuenta_individual(
        edad = edad,
        salario_mensual = salario_mensual,
        saldo_inicial = saldo_cuenta,
        densidad = densidad_simulada,
        edad_retiro = edad_retiro,
        tasa_aporte = tasa_aporte,
        retorno_real = retorno_real,
        crecimiento_salario = crecimiento_salario
      )),
      saldo_retiro = sim$saldo_retiro,
      salario_final_anual = sim$salario_final_anual,
      pension_autofinanciada_anual = calcular_pension_anual(
        saldo_retiro, edad_retiro, esperanza_vida, tasa_tecnica
      ),
      pension_final_anual = pmax(pension_autofinanciada_anual, pension_minima),
      costo_fiscal_anual = pmax(0, pension_minima - pension_autofinanciada_anual),
      tasa_reemplazo = pension_final_anual / salario_final_anual
    ) %>%
    ungroup() %>%
    select(-sim)
}

resultado_base <- simular_micro(
  micro,
  tasa_aporte = get_param("tasa_aporte_capitalizable"),
  edad_retiro = get_param("edad_retiro_base"),
  retorno_real = get_param("retorno_real_anual"),
  crecimiento_salario = get_param("crecimiento_salario_real"),
  pension_minima = 0,
  tasa_tecnica = get_param("tasa_tecnica_anual")
)

write_csv(resultado_base, file.path(paths$outputs, "resultados_individuales_base.csv"))
message("Resultados base guardados en outputs/resultados_individuales_base.csv")
