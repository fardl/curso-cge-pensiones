# Sesion 5 - Calibracion CGE con pensiones
# MACROPOL: Economia Aplicada y Politicas Publicas

rm(list = ls())

project_root <- normalizePath(file.path(getwd()), winslash = "/", mustWork = FALSE)

# Si ejecutas desde la carpeta R/, sube un nivel.
if (basename(project_root) == "R") {
  project_root <- dirname(project_root)
}

paths <- list(
  data = file.path(project_root, "data"),
  outputs = file.path(project_root, "outputs")
)

dir.create(paths$outputs, recursive = TRUE, showWarnings = FALSE)

read_sam <- function(file) {
  x <- read.csv(file, row.names = 1, check.names = FALSE)
  x <- as.matrix(x)
  storage.mode(x) <- "double"
  return(x)
}

check_sam_balance <- function(sam, tolerance = 1e-8) {
  rows <- rowSums(sam)
  cols <- colSums(sam)
  out <- data.frame(
    cuenta = rownames(sam),
    ingresos = as.numeric(rows),
    gastos = as.numeric(cols[rownames(sam)]),
    diferencia = as.numeric(rows - cols[rownames(sam)])
  )
  out$cuadra <- abs(out$diferencia) <= tolerance
  out
}
