# Diagnostico: el modelo calibrado debe reproducir el ano base
source("R/00_setup.R")

params <- readRDS(file.path(paths$outputs, "parametros_calibrados.rds"))

prod_va <- function(L, K, A, alpha_L, alpha_K) {
  A * L^alpha_L * K^alpha_K
}

VA_hat <- with(params$production,
               prod_va(params$base$L0, params$base$K0, A_va, alpha_L, alpha_K))

diagnostico <- data.frame(
  indicador = c("Valor agregado observado", "Valor agregado reproducido", "Error absoluto"),
  valor = c(params$base$VA0, VA_hat, abs(params$base$VA0 - VA_hat))
)

print(diagnostico)
write.csv(diagnostico, file.path(paths$outputs, "diagnostico_equilibrio_base.csv"), row.names = FALSE)
