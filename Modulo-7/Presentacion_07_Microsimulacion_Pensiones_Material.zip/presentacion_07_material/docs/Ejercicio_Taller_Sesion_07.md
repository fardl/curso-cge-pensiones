# Ejercicio de taller - Sesion 7

## Objetivo

Simular una reforma previsional y evaluar su efecto sobre tasas de reemplazo, pensiones y suficiencia por grupos de poblacion.

## Paso 1: Explorar la base

Abrir `data/microdatos_sinteticos.csv` y responder:

1. ¿Cual es la edad promedio?
2. ¿Que porcentaje de trabajadores es formal?
3. ¿Cual es la densidad promedio de cotizacion?
4. ¿Como cambia el salario mensual por quintil?

## Paso 2: Correr el escenario base

Ejecutar:

```r
source("R/02_simular_cuentas_individuales.R")
```

Revisar `outputs/resultados_individuales_base.csv`.

## Paso 3: Simular escenarios

Ejecutar:

```r
source("R/03_escenarios_reforma_micro.R")
```

Comparar:

- escenario base;
- aumento de aporte;
- aumento de edad de retiro;
- pilar solidario;
- formalizacion;
- paquete integral.

## Paso 4: Visualizar

Ejecutar:

```r
source("R/04_visualizacion_resultados.R")
```

Revisar la carpeta `figures/`.

## Paso 5: Interpretar como policy brief

Preparar una nota de una pagina que responda:

1. ¿Que reforma mejora mas la tasa de reemplazo mediana?
2. ¿Que reforma reduce mas la proporcion bajo pension minima?
3. ¿Que reforma genera costo fiscal?
4. ¿Que grupos ganan mas: quintiles bajos o altos?
5. ¿Que indicador podria deteriorarse en equilibrio general?

## Entregable

Una tabla resumen, dos graficos y cinco mensajes de politica publica.
