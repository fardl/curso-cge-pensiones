# ==========================================================
# Escenarios de reforma previsional en la microsimulacion
# ==========================================================

source("R/02_simular_cuentas_individuales.R")

escenarios <- read_csv(file.path(paths$data, "escenarios_micro.csv"), show_col_types = FALSE)

resumir_escenario <- function(df, escenario) {
  tibble(
    escenario = escenario,
    pension_promedio_ponderada = weighted_mean(df$pension_final_anual, df$peso),
    pension_mediana_ponderada = weighted_quantile(df$pension_final_anual, df$peso, 0.5),
    tr_promedio_ponderada = weighted_mean(df$tasa_reemplazo, df$peso),
    tr_mediana_ponderada = weighted_quantile(df$tasa_reemplazo, df$peso, 0.5),
    porc_bajo_minimo_autofinanciado = weighted_share(df$pension_autofinanciada_anual < 120000, df$peso),
    costo_fiscal_total_anual = sum(df$costo_fiscal_anual * df$peso, na.rm = TRUE),
    saldo_retiro_promedio = weighted_mean(df$saldo_retiro, df$peso)
  )
}

resultados_lista <- list()
resumen_lista <- list()

for (k in seq_len(nrow(escenarios))) {
  esc <- escenarios[k, ]
  res <- simular_micro(
    micro,
    tasa_aporte = esc$tasa_aporte,
    edad_retiro = esc$edad_retiro,
    retorno_real = esc$retorno_real,
    crecimiento_salario = esc$crecimiento_salario,
    shock_densidad = esc$shock_densidad,
    pension_minima = esc$pension_minima,
    tasa_tecnica = get_param("tasa_tecnica_anual")
  ) %>%
    mutate(escenario = esc$escenario)

  resultados_lista[[esc$escenario]] <- res
  resumen_lista[[esc$escenario]] <- resumir_escenario(res, esc$escenario)
}

resultados_todos <- bind_rows(resultados_lista)
resumen_escenarios <- bind_rows(resumen_lista)

write_csv(resultados_todos, file.path(paths$outputs, "resultados_individuales_escenarios.csv"))
write_csv(resumen_escenarios, file.path(paths$outputs, "resumen_escenarios_micro.csv"))

resumen_quintiles <- resultados_todos %>%
  group_by(escenario, quintil) %>%
  summarise(
    pension_promedio = weighted_mean(pension_final_anual, peso),
    tr_promedio = weighted_mean(tasa_reemplazo, peso),
    bajo_minimo = weighted_share(pension_autofinanciada_anual < 120000, peso),
    .groups = "drop"
  )
write_csv(resumen_quintiles, file.path(paths$outputs, "resumen_quintiles_escenarios.csv"))

message("Escenarios simulados y guardados en outputs/.")
