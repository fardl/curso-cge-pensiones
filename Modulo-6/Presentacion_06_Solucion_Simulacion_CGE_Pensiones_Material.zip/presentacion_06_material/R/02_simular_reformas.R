# ================================================================
# Sesion 6 - Solucion y simulacion del modelo CGE con pensiones
# 02_simular_reformas.R
# ================================================================

source("R/00_setup.R")
source("R/01_modelo_cge_pensiones.R")

par <- leer_parametros()
esc <- leer_escenarios()

# Convierte cada fila del archivo de escenarios en una lista de choques.
crear_shock <- function(row) {
  vars <- setdiff(names(row), "escenario")
  shock <- as.list(row[vars])
  shock <- shock[!is.na(shock)]
  shock <- shock[sapply(shock, function(z) length(z) > 0)]
  shock <- lapply(shock, as.numeric)
  shock
}

escenarios <- list(base = list())
for (i in seq_len(nrow(esc))) {
  escenarios[[esc$escenario[i]]] <- crear_shock(esc[i, , drop = FALSE])
}

resultados <- lapply(escenarios, function(s) resolver_cge(par, s))
resultados_df <- do.call(rbind, lapply(names(resultados), function(nm) {
  data.frame(escenario = nm, variable = names(resultados[[nm]]),
             valor = as.numeric(unlist(resultados[[nm]])), row.names = NULL)
}))

cambios_df <- comparar_con_base(resultados)

write.csv(resultados_df, file.path(paths$outputs, "resultados_escenarios.csv"), row.names = FALSE)
write.csv(cambios_df, file.path(paths$outputs, "cambios_porcentuales.csv"), row.names = FALSE)

print(subset(cambios_df, variable %in% c("PIB", "consumo", "inversion", "empleo", "contribuciones_afp", "balance_fiscal")))
