# Presentacion 5 - Calibracion del modelo CGE con pensiones

Este paquete contiene:

- `latex/Presentacion_05_Calibracion_CGE_Pensiones.tex`: fuente Beamer.
- `data/sam_base_calibracion.csv`: SAM sintetica balanceada para ejercicios.
- `R/00_setup.R`: funciones basicas para leer y validar la SAM.
- `R/01_calibrar_parametros.R`: calibracion de parametros de produccion, hogares, gobierno y AFP.
- `R/02_diagnostico_equilibrio_base.R`: verificacion de reproduccion del ano base.
- `R/03_simular_aumento_contribucion.R`: simulacion contable preliminar de aumento de contribucion.

## Orden sugerido de ejecucion

Desde la carpeta `presentacion_05_material`:

```r
source("R/01_calibrar_parametros.R")
source("R/02_diagnostico_equilibrio_base.R")
source("R/03_simular_aumento_contribucion.R")
```

La simulacion del script 03 es pedagogica y contable. El CGE completo se desarrollara en las sesiones posteriores.
