
# Material practico - Sesion SAM para CGE de Pensiones

Este paquete acompaña la Presentacion 4 del curso **Modelos CGE y Microsimulacion aplicados al Sistema de Pensiones de Capitalizacion Individual**.

## Estructura

```text
sam_material/
├── data/
│   ├── sam_sintetica_rd.csv
│   └── flujos_sam_sintetica_rd.csv
├── templates/
│   ├── sam_accounts_template.csv
│   ├── catalogo_datos_SAM_RD.csv
│   ├── fuentes_oficiales_RD.csv
│   └── mapa_cuentas_sam_rd.csv
├── R/
│   ├── 00_setup.R
│   ├── 01_crear_sam_sintetica.R
│   ├── 02_validar_sam.R
│   ├── 03_balance_ras.R
│   ├── 04_visualizar_sam.R
│   └── 05_checklist_datos_rd.R
├── docs/
│   └── Guia_Datos_SAM_RD.md
└── latex/
    └── Presentacion_04_SAM_CGE_Pensiones.tex
```

## Orden sugerido de trabajo

1. Abrir `templates/sam_accounts_template.csv` y discutir las cuentas.
2. Cargar `data/sam_sintetica_rd.csv`.
3. Ejecutar `R/02_validar_sam.R` para verificar cierre contable.
4. Ejecutar `R/04_visualizar_sam.R` para producir un heatmap.
5. Revisar `templates/catalogo_datos_SAM_RD.csv` y asignar fuentes por bloque.
6. Adaptar el mapa de cuentas a la economia dominicana real.

## Requisitos en R

Paquetes sugeridos:

```r
install.packages(c("tidyverse", "readr", "ggplot2", "viridis"))
```

Los scripts usan rutas relativas. Ejecutar desde la carpeta `sam_material/`.
