# ============================================================
# 02_limpieza_datos.R
# Limpieza, validacion y construccion de variables previsionales
# ============================================================

source(here::here("R", "00_setup.R"))
source(here::here("R", "01_importar_datos.R"))

personas_clean <- personas |>
  filter(edad >= 15, edad <= 100) |>
  mutate(
    ingreso_laboral = if_else(ingreso_laboral < 0, NA_real_, ingreso_laboral),
    saldo_afp       = if_else(saldo_afp < 0, NA_real_, saldo_afp),
    formal          = if_else(formal == 1, "Formal", "Informal"),
    afiliado_afp    = if_else(afiliado_afp == 1, "Afiliado", "No afiliado"),
    grupo_edad = case_when(
      edad < 30 ~ "15-29",
      edad < 45 ~ "30-44",
      edad < 60 ~ "45-59",
      TRUE      ~ "60+"
    ),
    cotizante = if_else(formal == "Formal" & afiliado_afp == "Afiliado", 1, 0),
    aporte_anual_estimado = ingreso_laboral * 12 * 0.10 * cotizante,
    quintil_ingreso = ntile(ingreso_laboral, 5),
    tasa_aporte_efectiva = aporte_anual_estimado / (ingreso_laboral * 12)
  )

readr::write_csv(
  personas_clean,
  here::here("data", "clean", "personas_pensiones_clean.csv")
)

indicadores <- personas_clean |>
  summarise(
    poblacion = sum(factor_expansion, na.rm = TRUE),
    cobertura_afp = weighted.mean(afiliado_afp == "Afiliado", factor_expansion, na.rm = TRUE),
    formalidad = weighted.mean(formal == "Formal", factor_expansion, na.rm = TRUE),
    ingreso_promedio = weighted.mean(ingreso_laboral, factor_expansion, na.rm = TRUE),
    saldo_promedio = weighted.mean(saldo_afp, factor_expansion, na.rm = TRUE)
  )

readr::write_csv(indicadores, here::here("outputs", "tables", "indicadores_basicos.csv"))
print(indicadores)
