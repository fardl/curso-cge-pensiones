# ================================================================
# Sesion 6 - Solucion y simulacion del modelo CGE con pensiones
# 03_visualizar_resultados.R
# ================================================================
# Requiere ggplot2. Si no esta instalado, ejecutar install.packages("ggplot2").

source("R/00_setup.R")

cambios <- read.csv(file.path(paths$outputs, "cambios_porcentuales.csv"))

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  stop("Instale ggplot2 para generar graficos: install.packages('ggplot2')")
}

library(ggplot2)

vars <- c("PIB", "consumo", "inversion", "empleo", "contribuciones_afp", "balance_fiscal")
plot_df <- subset(cambios, variable %in% vars & escenario != "base")

p <- ggplot(plot_df, aes(x = escenario, y = cambio_pct)) +
  geom_col() +
  facet_wrap(~ variable, scales = "free_y") +
  labs(
    title = "Cambios porcentuales frente al benchmark",
    x = "Escenario",
    y = "Cambio porcentual"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave(file.path(paths$outputs, "grafico_cambios_porcentuales.png"), p, width = 10, height = 6, dpi = 150)
print(p)
