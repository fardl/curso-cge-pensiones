# 03_balance_ras.R
# Funcion RAS para balancear una matriz con totales objetivo de filas y columnas.
# Ejecutar desde la carpeta sam_material/

source("R/00_setup.R")

ras_balance <- function(A, target_rows, target_cols, tol = 1e-8, max_iter = 10000) {
  if (abs(sum(target_rows) - sum(target_cols)) > tol) {
    stop("Los totales objetivo de filas y columnas no suman lo mismo.")
  }
  if (any(A < 0)) stop("RAS estandar requiere matriz no negativa.")
  if (any(target_rows < 0) || any(target_cols < 0)) stop("Los objetivos deben ser no negativos.")

  X <- A
  eps <- .Machine$double.eps

  for (iter in seq_len(max_iter)) {
    rs <- rowSums(X)
    r_factor <- ifelse(rs > eps, target_rows / rs, 0)
    X <- diag(r_factor, nrow = length(r_factor)) %*% X

    cs <- colSums(X)
    c_factor <- ifelse(cs > eps, target_cols / cs, 0)
    X <- X %*% diag(c_factor, nrow = length(c_factor))

    err <- max(abs(rowSums(X) - target_rows), abs(colSums(X) - target_cols))
    if (err < tol) {
      attr(X, "iterations") <- iter
      attr(X, "error") <- err
      return(X)
    }
  }

  attr(X, "iterations") <- max_iter
  attr(X, "error") <- max(abs(rowSums(X) - target_rows), abs(colSums(X) - target_cols))
  warning("RAS no convergio dentro del maximo de iteraciones.")
  X
}

# Ejemplo pedagogico: perturbar la SAM sintetica y re-balancear
sam <- as.matrix(read.csv("data/sam_sintetica_rd.csv", row.names = 1, check.names = FALSE))
storage.mode(sam) <- "numeric"

A0 <- sam
A0["AFP", "HH5"] <- A0["AFP", "HH5"] + 2  # aumento hipotetico de contribuciones
A0["IND", "HH5"] <- max(A0["IND", "HH5"] - 2, 0) # menor consumo industrial del HH5

target_rows <- rowSums(sam)
target_cols <- colSums(sam)

balanced <- ras_balance(A0, target_rows, target_cols)
write.csv(balanced, "outputs/tables/sam_balanceada_ras.csv")

message("Iteraciones RAS: ", attr(balanced, "iterations"))
message("Error final RAS: ", signif(attr(balanced, "error"), 4))
