# Sesion 2 - R, estructura del proyecto, limpieza de datos y visualizacion

Este paquete contiene una base sintetica y scripts iniciales para el curso **Modelos CGE y Microsimulacion aplicados al Sistema de Pensiones de Capitalizacion Individual**.

## Orden de ejecucion

1. `R/00_setup.R`
2. `R/01_importar_datos.R`
3. `R/02_limpieza_datos.R`
4. `R/03_visualizacion.R`

## Producto esperado

- Base limpia: `data/clean/personas_pensiones_clean.csv`
- Indicadores basicos: `outputs/tables/indicadores_basicos.csv`
- Figuras: `outputs/figures/`
