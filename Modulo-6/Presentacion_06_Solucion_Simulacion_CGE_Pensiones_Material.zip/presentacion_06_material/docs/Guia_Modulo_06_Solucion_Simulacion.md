# Guia del Modulo 6: Solucion y Simulacion del Modelo CGE con Pensiones

## Objetivo

El objetivo de esta sesion es pasar de un modelo calibrado a un modelo capaz de simular reformas previsionales. El foco no esta en construir un CGE completo multisectorial, sino en entender la mecanica de solucion: variables endogenas, variables exogenas, cierres macroeconomicos, choques y comparacion contra el escenario base.

## Flujo de trabajo

1. Cargar parametros base desde `data/parametros_base.csv`.
2. Definir escenarios de reforma en `data/escenarios_reforma.csv`.
3. Ejecutar `R/02_simular_reformas.R`.
4. Revisar `outputs/resultados_escenarios.csv` y `outputs/cambios_porcentuales.csv`.
5. Ejecutar `R/03_visualizar_resultados.R` para producir graficos.

## Reformas incluidas

- Aumento de contribucion previsional a 14%.
- Pilar solidario financiado con mayor impuesto al consumo.
- Aumento de edad de retiro aproximado como mayor oferta laboral efectiva y menores beneficios en el periodo.
- Mayor rentabilidad neta del fondo AFP.
- Choque financiero negativo sobre rentabilidad AFP.
- Paquete de reforma combinada.

## Lectura de resultados

Los resultados deben interpretarse como desviaciones contra el benchmark. No representan estimaciones oficiales para Republica Dominicana. Son ejercicios pedagogicos para entender mecanismos.

Indicadores clave:

- PIB.
- Consumo.
- Inversion.
- Empleo y empleo formal.
- Contribuciones AFP.
- Activos AFP al periodo siguiente.
- Balance fiscal.
- Formalidad.

## Preguntas para discusion

1. Que cierre fiscal se uso para financiar el pilar solidario?
2. El aumento de contribucion eleva ahorro nacional o sustituye ahorro voluntario?
3. Que ocurre con el empleo formal?
4. Como cambiaria el resultado si la elasticidad de formalidad fuera mayor?
5. Que resultados deben pasar a la microsimulacion?

## Advertencia metodologica

El modelo incluido es una version didactica agregada. Un CGE aplicado completo deberia incluir multiples sectores, hogares desagregados, comercio exterior, impuestos detallados, cuentas institucionales, cierres explicitos y calibracion desde una SAM balanceada.
