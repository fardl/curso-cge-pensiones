# 04_visualizar_sam.R
# Visualiza la SAM sintetica como mapa de calor.
# Ejecutar desde la carpeta sam_material/

source("R/00_setup.R")

for (pkg in c("ggplot2", "viridis")) {
  if (!requireNamespace(pkg, quietly = TRUE)) stop("Falta instalar el paquete: ", pkg)
}

sam <- as.matrix(read.csv("data/sam_sintetica_rd.csv", row.names = 1, check.names = FALSE))
storage.mode(sam) <- "numeric"

sam_long <- as.data.frame(as.table(sam), stringsAsFactors = FALSE)
names(sam_long) <- c("recibe", "paga", "valor")

p <- ggplot2::ggplot(sam_long, ggplot2::aes(x = paga, y = recibe, fill = valor)) +
  ggplot2::geom_tile(color = "white", linewidth = 0.2) +
  viridis::scale_fill_viridis(option = "C", direction = -1) +
  ggplot2::labs(
    title = "Matriz de Contabilidad Social sintetica",
    subtitle = "Filas reciben, columnas pagan",
    x = "Cuenta que paga",
    y = "Cuenta que recibe",
    fill = "Flujo"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))

ggplot2::ggsave("outputs/figures/heatmap_sam_sintetica.png", p, width = 10, height = 7, dpi = 150)
message("Grafico guardado en outputs/figures/heatmap_sam_sintetica.png")
