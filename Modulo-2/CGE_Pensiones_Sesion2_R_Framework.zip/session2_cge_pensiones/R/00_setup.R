# ============================================================
# 00_setup.R
# Curso CGE y Microsimulacion de Pensiones
# Configuracion general del proyecto
# ============================================================

rm(list = ls())

paquetes <- c(
  "tidyverse", "data.table", "janitor", "here",
  "readxl", "scales", "skimr"
)

instalar <- paquetes[!paquetes %in% installed.packages()[, "Package"]]
if (length(instalar) > 0) install.packages(instalar)

invisible(lapply(paquetes, library, character.only = TRUE))

path_raw   <- here::here("data", "raw")
path_clean <- here::here("data", "clean")
path_fig   <- here::here("outputs", "figures")
path_tab   <- here::here("outputs", "tables")

dir.create(path_clean, recursive = TRUE, showWarnings = FALSE)
dir.create(path_fig, recursive = TRUE, showWarnings = FALSE)
dir.create(path_tab, recursive = TRUE, showWarnings = FALSE)
