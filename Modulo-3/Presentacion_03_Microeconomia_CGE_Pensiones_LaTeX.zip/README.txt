Presentacion 03 - Microeconomia para Modelos CGE y Pensiones

Contenido:
- Presentacion_03_Microeconomia_CGE_Pensiones.tex

Compilacion sugerida:
latexmk -pdf Presentacion_03_Microeconomia_CGE_Pensiones.tex

Requiere una distribucion LaTeX con beamer, tikz, amsmath, booktabs y listings.
