# ============================================================
# 03_visualizacion.R
# Graficos iniciales de diagnostico previsional
# ============================================================

source(here::here("R", "00_setup.R"))
source(here::here("R", "02_limpieza_datos.R"))

p1 <- personas_clean |>
  group_by(quintil_ingreso) |>
  summarise(
    cobertura = weighted.mean(afiliado_afp == "Afiliado", factor_expansion, na.rm = TRUE),
    .groups = "drop"
  ) |>
  ggplot(aes(x = factor(quintil_ingreso), y = cobertura)) +
  geom_col() +
  scale_y_continuous(labels = scales::percent) +
  labs(
    title = "Cobertura AFP por quintil de ingreso",
    x = "Quintil de ingreso laboral",
    y = "Cobertura"
  ) +
  theme_minimal()

p2 <- personas_clean |>
  filter(!is.na(ingreso_laboral)) |>
  ggplot(aes(x = edad, y = ingreso_laboral)) +
  geom_point(alpha = 0.15) +
  geom_smooth(se = FALSE) +
  facet_wrap(~ formal) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "Perfil edad-ingreso por formalidad",
    x = "Edad",
    y = "Ingreso laboral mensual"
  ) +
  theme_minimal()

p3 <- personas_clean |>
  filter(afiliado_afp == "Afiliado") |>
  ggplot(aes(x = grupo_edad, y = saldo_afp)) +
  geom_boxplot(outlier.alpha = 0.2) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "Distribucion del saldo AFP por grupo de edad",
    x = "Grupo de edad",
    y = "Saldo acumulado"
  ) +
  theme_minimal()

ggsave(here::here("outputs", "figures", "cobertura_quintil.png"), p1, width = 8, height = 5, dpi = 300)
ggsave(here::here("outputs", "figures", "perfil_edad_ingreso.png"), p2, width = 8, height = 5, dpi = 300)
ggsave(here::here("outputs", "figures", "saldo_afp_edad.png"), p3, width = 8, height = 5, dpi = 300)

print(p1)
print(p2)
print(p3)
