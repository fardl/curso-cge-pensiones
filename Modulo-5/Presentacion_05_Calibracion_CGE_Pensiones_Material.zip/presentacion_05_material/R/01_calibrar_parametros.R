# Calibracion de parametros a partir de una SAM simplificada
source("R/00_setup.R")

sam <- read_sam(file.path(paths$data, "sam_base_calibracion.csv"))
check <- check_sam_balance(sam)
print(check)
stopifnot(all(check$cuadra))

# Convencion: fila recibe, columna paga.
Y0 <- colSums(sam)["PROD"]
L0 <- sam["LAB", "PROD"]
K0 <- sam["CAP", "PROD"]
VA0 <- L0 + K0

# Produccion Cobb-Douglas: VA = A * L^alpha_L * K^alpha_K
alpha_L <- L0 / VA0
alpha_K <- K0 / VA0
A_va <- VA0 / (L0^alpha_L * K0^alpha_K)

# Ingreso hogares y decisiones agregadas
YH0 <- rowSums(sam)["HOG"]
C0 <- sam["PROD", "HOG"]
T_hh0 <- sam["GOV", "HOG"]
Contr0 <- sam["AFP", "HOG"]
S_hh0 <- sam["INV", "HOG"]

# Tasas promedio calibradas
c_share <- C0 / YH0
tau_hh <- T_hh0 / YH0
s_hh <- S_hh0 / YH0
contr_income_rate <- Contr0 / YH0
contr_wage_rate <- Contr0 / L0

# Gobierno
YG0 <- rowSums(sam)["GOV"]
G0 <- sam["PROD", "GOV"]
TR_gov_hh0 <- sam["HOG", "GOV"]
tau_prod <- sam["GOV", "PROD"] / Y0

# AFP
YAFP0 <- rowSums(sam)["AFP"]
benef0 <- sam["HOG", "AFP"]
S_afp0 <- sam["INV", "AFP"]
ret_afp0 <- sam["AFP", "CAP"]
benef_share <- benef0 / YAFP0
s_afp <- S_afp0 / YAFP0

params <- list(
  base = list(Y0 = Y0, L0 = L0, K0 = K0, VA0 = VA0),
  production = list(alpha_L = alpha_L, alpha_K = alpha_K, A_va = A_va),
  household = list(YH0 = YH0, C0 = C0, c_share = c_share, tau_hh = tau_hh,
                   s_hh = s_hh, contr_income_rate = contr_income_rate,
                   contr_wage_rate = contr_wage_rate),
  government = list(YG0 = YG0, G0 = G0, tau_prod = tau_prod,
                    transfers_to_households = TR_gov_hh0),
  pension = list(YAFP0 = YAFP0, benefits = benef0, returns = ret_afp0,
                 s_afp = s_afp, benefit_share = benef_share)
)

print(params)
saveRDS(params, file.path(paths$outputs, "parametros_calibrados.rds"))
write.csv(check, file.path(paths$outputs, "check_balance_sam.csv"), row.names = FALSE)
