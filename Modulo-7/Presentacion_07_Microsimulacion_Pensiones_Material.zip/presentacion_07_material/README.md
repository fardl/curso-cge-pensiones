# Sesion 7 - Microsimulacion de Pensiones de Capitalizacion Individual

Este paquete contiene la presentacion Beamer y material practico en R para proyectar cuentas individuales, pensiones y tasas de reemplazo.

## Contenido

- `latex/Presentacion_07_Microsimulacion_Pensiones.tex`: fuente LaTeX Beamer.
- `latex/Presentacion_07_Microsimulacion_Pensiones.pdf`: PDF compilado.
- `R/00_setup.R`: carga paquetes, define rutas y funciones auxiliares.
- `R/01_generar_microdatos_sinteticos.R`: crea una base sintetica de trabajadores.
- `R/02_simular_cuentas_individuales.R`: proyecta saldos, pensiones y tasas de reemplazo.
- `R/03_escenarios_reforma_micro.R`: simula escenarios de reforma.
- `R/04_visualizacion_resultados.R`: genera graficos.
- `R/05_topdown_cge_micro.R`: ejemplo de integracion top-down desde el CGE.
- `data/`: microdatos sinteticos, parametros, escenarios y diccionario.
- `outputs/`: resultados de ejemplo ya generados.
- `docs/`: guia de datos y diccionario de resultados.

## Orden sugerido de ejecucion

Desde la carpeta raiz del paquete:

```r
source("R/00_setup.R")
source("R/01_generar_microdatos_sinteticos.R")
source("R/02_simular_cuentas_individuales.R")
source("R/03_escenarios_reforma_micro.R")
source("R/04_visualizacion_resultados.R")
source("R/05_topdown_cge_micro.R")
```

## Nota metodologica

Los datos son sinteticos y solo sirven para docencia. Para una aplicacion institucional se debe reemplazar la base por microdatos anonimizados de encuestas y registros administrativos, y calibrar salarios, densidad, cotizantes, saldos y beneficios contra agregados oficiales.
