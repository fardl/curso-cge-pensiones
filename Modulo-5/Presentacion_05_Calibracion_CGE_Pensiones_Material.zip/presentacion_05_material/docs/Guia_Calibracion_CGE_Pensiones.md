# Guia breve - Calibracion CGE con pensiones

## 1. Idea central

La calibracion transforma una SAM balanceada en parametros del modelo. El objetivo es que el equilibrio sin reforma reproduzca exactamente el ano base.

## 2. Convencion de la SAM

- Fila: cuenta que recibe ingresos.
- Columna: cuenta que realiza pagos.
- Para cada cuenta: suma de fila = suma de columna.

## 3. Parametros principales

### Produccion

- Participacion laboral: pagos al trabajo / valor agregado.
- Participacion del capital: pagos al capital / valor agregado.
- Escala Cobb-Douglas: valor que reproduce el valor agregado base.

### Hogares

- Propension media al consumo.
- Tasa media de ahorro voluntario.
- Tasa efectiva de contribucion previsional.
- Tasa media de impuesto directo.

### Gobierno

- Tasas impositivas promedio.
- Transferencias a hogares.
- Gasto publico real o balance fiscal, segun cierre.

### AFP / Fondo previsional

- Contribuciones recibidas.
- Rendimientos financieros.
- Beneficios pagados.
- Ahorro neto del fondo.

## 4. Validacion

Antes de simular reformas, verificar:

1. La SAM esta balanceada.
2. Los parametros reproducen el valor agregado base.
3. La cuenta de hogares cierra.
4. La cuenta AFP cierra.
5. El cierre macroeconomico esta documentado.

## 5. Uso pedagogico de los scripts

Los scripts entregados son una base didactica. No sustituyen todavia al solucionador CGE completo. Sirven para pasar de la SAM a parametros y preparar las ecuaciones de la siguiente sesion.
