# ==========================================================
# Generar microdatos sinteticos para microsimulacion previsional
# ==========================================================

source("R/00_setup.R")
set.seed(77)

n <- 5000
id <- seq_len(n)
edad <- sample(25:60, n, replace = TRUE)
sexo <- sample(c("Mujer", "Hombre"), n, replace = TRUE, prob = c(0.49, 0.51))
educacion <- sample(c("Primaria", "Secundaria", "Tecnica", "Universitaria"),
                    n, replace = TRUE, prob = c(0.24, 0.38, 0.16, 0.22))
sector <- sample(c("Agropecuario", "Manufactura", "Construccion", "Comercio", "Servicios", "Publico"),
                 n, replace = TRUE, prob = c(0.08, 0.12, 0.11, 0.22, 0.34, 0.13))

prob_formal <- 0.35 +
  0.10 * (educacion == "Tecnica") +
  0.25 * (educacion == "Universitaria") +
  0.20 * (sector == "Publico") -
  0.12 * (sector == "Agropecuario") -
  0.08 * (sector == "Construccion") +
  0.003 * (edad - 35)
prob_formal <- pmin(pmax(prob_formal, 0.08), 0.92)
formal <- rbinom(n, 1, prob_formal)

quintil <- sample(1:5, n, replace = TRUE, prob = c(0.22, 0.22, 0.21, 0.19, 0.16))

efecto_educ <- c(Primaria = 0, Secundaria = 0.25, Tecnica = 0.43, Universitaria = 0.72)
efecto_sector <- c(Agropecuario = -0.15, Manufactura = 0.04, Construccion = 0.05,
                   Comercio = 0.00, Servicios = 0.11, Publico = 0.19)
mu <- 10.25 + 0.23 * (quintil - 3) + efecto_educ[educacion] + efecto_sector[sector] +
  0.15 * formal + 0.006 * (edad - 40)
salario_mensual <- exp(rnorm(n, mu, 0.42))
salario_mensual <- pmin(pmax(salario_mensual, 12000), 220000)

densidad_historica <- ifelse(formal == 1,
                             rbeta(n, 7, 2.3),
                             rbeta(n, 2.0, 7.2))
densidad_historica <- pmin(pmax(densidad_historica, 0.02), 0.98)
meses_cotizados_ult_ano <- round(densidad_historica * 12)

anios_trabajo <- pmax(edad - 22, 0)
saldo_cuenta <- salario_mensual * 12 * 0.08 * densidad_historica * anios_trabajo * runif(n, 0.6, 1.7)
saldo_cuenta <- ifelse(formal == 1, saldo_cuenta, saldo_cuenta * runif(n, 0.05, 0.45))

micro <- tibble(
  id = id,
  peso = round(runif(n, 80, 550), 3),
  edad = edad,
  sexo = sexo,
  educacion = educacion,
  sector = sector,
  formal = formal,
  quintil = quintil,
  salario_mensual = round(salario_mensual, 2),
  meses_cotizados_ult_ano = meses_cotizados_ult_ano,
  densidad_historica = round(densidad_historica, 4),
  saldo_cuenta = round(saldo_cuenta, 2),
  edad_retiro_base = 65,
  esperanza_vida = round(pmin(pmax(ifelse(sexo == "Mujer", 84, 81) + rnorm(n, 0, 1.5), 76), 90), 1)
)

write_csv(micro, file.path(paths$data, "microdatos_sinteticos.csv"))
message("Microdatos sinteticos guardados en data/microdatos_sinteticos.csv")
