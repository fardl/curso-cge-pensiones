# 05_checklist_datos_rd.R
# Lee el catalogo de datos para la SAM dominicana y produce una lista por prioridad.
# Ejecutar desde la carpeta sam_material/

source("R/00_setup.R")

catalog_path <- "templates/catalogo_datos_SAM_RD.csv"
if (!file.exists(catalog_path)) stop("No existe el archivo: ", catalog_path)

catalogo <- read.csv(catalog_path, stringsAsFactors = FALSE)

prioridad_1 <- subset(catalogo, prioridad == "Prioridad 1")
write.csv(prioridad_1, "outputs/tables/checklist_prioridad_1_sam_rd.csv", row.names = FALSE)

cat("\n=== Datos Prioridad 1 para SAM RD ===\n")
print(prioridad_1[, c("bloque", "variable", "fuente_prioritaria")], row.names = FALSE)

message("Checklist guardado en outputs/tables/checklist_prioridad_1_sam_rd.csv")
