# Diccionario de variables del modelo didactico

| Variable | Descripcion |
|---|---|
| PIB | Produccion real agregada del periodo. |
| empleo | Trabajo total utilizado en produccion. |
| empleo_formal | Trabajo formal cotizante. |
| salario_bruto | Salario bruto promedio. |
| salario_neto | Salario neto despues de carga laboral y contribucion previsional efectiva. |
| consumo | Consumo privado agregado. |
| inversion | Inversion determinada por el cierre ahorro-inversion. |
| ahorro_total | Ahorro voluntario + ahorro fiscal + ahorro AFP + ahorro externo. |
| ahorro_voluntario | Ahorro no obligatorio de los hogares. |
| contribuciones_afp | Contribuciones obligatorias al sistema de capitalizacion individual. |
| ahorro_afp | Contribuciones AFP netas de beneficios y comisiones. |
| activos_afp_siguiente | Activos administrados por AFP al periodo siguiente. |
| beneficios | Beneficios previsionales pagados en el periodo. |
| balance_fiscal | Ingresos publicos menos gasto publico, transferencias y pilar. |
| ingreso_gobierno | Recaudacion laboral, consumo y capital. |
| gasto_gobierno | Gasto publico total. |
| formalidad | Proporcion del empleo que cotiza. |
| capital_siguiente | Stock de capital del siguiente periodo. |
| bienestar_proxy | Indicador pedagogico de bienestar agregado. |
