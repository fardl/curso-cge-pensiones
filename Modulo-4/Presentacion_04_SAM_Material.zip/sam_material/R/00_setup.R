# 00_setup.R
# Sesion SAM - CGE Pensiones
# Ejecutar desde la carpeta sam_material/

required_dirs <- c("data", "templates", "outputs", "outputs/figures", "outputs/tables")
for (d in required_dirs) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
}

message("Estructura de carpetas verificada.")

required_packages <- c("readr", "dplyr", "tidyr", "ggplot2", "viridis")
missing <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]

if (length(missing) > 0) {
  message("Paquetes faltantes: ", paste(missing, collapse = ", "))
  message("Instalar con: install.packages(c(", paste(sprintf('\\"%s\\"', missing), collapse = ", "), "))")
} else {
  message("Todos los paquetes sugeridos estan instalados.")
}
